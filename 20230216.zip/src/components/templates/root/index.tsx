import React from "react";
import { Outlet } from "react-router-dom";
// import { useTranslation } from "react-i18next";
// import { hideChangeRouteLoading } from "src/app/router/lib";
const Root = () => {

	return <><Outlet /></>;
};

export default Root;