import React from "react";
const Home = () => {
	return <>HOME PAGE</>;
};
export default Home;