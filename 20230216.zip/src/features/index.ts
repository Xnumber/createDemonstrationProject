import ThemeControllerSlice from "./theme/themeControllerSlice";
import LoadingSlice from "./loading/loadingSlice";
export { ThemeControllerSlice, LoadingSlice };