/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable no-undef */
const livereload = require("livereload");
const connectLivereload = require("connect-livereload");
const path = require("path");
const express = require("express");
const app = express();
const port = 6001;
const liveReloadServer = livereload.createServer();

liveReloadServer.watch(path.join(__dirname, "dist"));

app.use(connectLivereload());
app.use(express.static("dist"));
app.get(new RegExp("^/([^a]|a[^s]|as[^s]|ass[^e]|asse[^t]|assets[^/]).*$", "g"), function(req, res){
	res.sendFile("index.html", {
		root: "dist"
	});
});
app.listen(port, () => {
	console.log(`App listening on port ${port}`);
});
// https://stackoverflow.com/questions/45622125/how-can-i-add-live-reload-to-my-nodejs-server